# edited lynx -dump of wiki:
release-notes.txt
# raw output of lynx -source of wiki:
release-notes.html


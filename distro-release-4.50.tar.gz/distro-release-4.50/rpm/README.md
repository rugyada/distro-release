This is a default configuration files for building RPM packages for OpenMandriva Lx distribution.

https://openmandriva.org

Please run update_macrosh.sh

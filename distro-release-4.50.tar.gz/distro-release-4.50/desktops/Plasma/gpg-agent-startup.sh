#!/bin/sh

eval "$(gpg-agent --daemon)"

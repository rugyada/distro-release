Please regenerate fonts:
grub2-mkfont -v -s 14 -o unifont-regular-14.pf2 /usr/share/fonts/TTF/unifont/unifont.ttf

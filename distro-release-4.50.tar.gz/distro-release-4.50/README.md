This repository contains basic OpenMandriva Lx setup:
- versioning
- branding
- theme
- settings
- installer configurations
- rpm configurations
- common-licenses
- indexhtml

Directory layout:

- desktops

    a place where all common files and specific to given desktop files lives

- docs

    various documentation, including release-notes

- installer

    configuration files for installer application

- rpm
    configuration files and options for RPM build system

- theme

    a place for files related to common theme and specific for a desktop too

- common-licenses

    a place for files related to licenses
